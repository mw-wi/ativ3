let soma = 0;

        for (let i = 1; i <= 100; i++) {
            soma += i; 
        }
        alert("a soma dos numeros de 1 a 100 é: " + soma);