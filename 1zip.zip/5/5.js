let n = [4,10,2,5,7,1];
let mn=n[0];
for (let index = 0; index < 6; index++) {
     if (n[index] > mn){
        mn=n[index];
     }

}
console.log(mn);