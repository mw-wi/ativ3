let p = prompt("Digite uma palavra:");
let pi= "";

for (let i = p.length - 1; i >= 0; i--) {
  pi += p[i];
}

console.log(pi);