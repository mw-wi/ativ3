for (let i =1; i<=5; i++){
    let linha ="";
    for (let j = 0; j < i; j++) {
      linha +=i;
        }
        console.log(linha);
}